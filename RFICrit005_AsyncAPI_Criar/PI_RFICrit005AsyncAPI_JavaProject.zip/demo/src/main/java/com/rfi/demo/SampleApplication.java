package com.rfi.demo;

import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.apache.kafka.clients.CommonClientConfigs;
import java.time.Duration;
import java.util.Collections;
import java.util.Properties;
import org.apache.avro.Schema;
import org.apache.avro.generic.GenericDatumReader;
import org.apache.avro.generic.GenericRecord;
import java.io.File;
import java.io.ByteArrayInputStream;
import java.io.Console;

import org.apache.avro.io.Decoder;
import org.apache.avro.io.DecoderFactory;
import org.apache.kafka.common.config.SaslConfigs;
import org.apache.kafka.common.config.SslConfigs;

public class SampleApplication {
  public static final void main(String args[]) {  
    Schema.Parser schemaDefinitionParser = new Schema.Parser();
    Schema schema = null;
    try {
      schema = schemaDefinitionParser.parse(new File("C:/@ZZZ/@Workspaces/SpringToolSuite/demo/STUDENTZZ.FLIGHT.LANDINGS.avsc"));
    } catch (Exception e) {
      e.printStackTrace();
      System.exit(1);
    }

    GenericDatumReader<GenericRecord> reader = new GenericDatumReader<GenericRecord>(schema);

    Properties props = new Properties();

    props.put("bootstrap.servers", "my-eem-gateway-ibm-egw-rt-event-automation.apps.rey.coc-ibm.com:443");
    props.put("key.deserializer", "org.apache.kafka.common.serialization.StringDeserializer");
    props.put("value.deserializer", "org.apache.kafka.common.serialization.ByteArrayDeserializer");

    props.put("group.id", "1");
//    props.put("client.id", "04e9f1fd-ef1d-4cd0-b658-5ed88eb6b1fc");
    props.put("client.id", "88cc927b-4b55-45f8-8f18-a6a6f2b8e5f8");
  
    props.put(CommonClientConfigs.SECURITY_PROTOCOL_CONFIG, "SASL_SSL");
    props.put(SaslConfigs.SASL_MECHANISM, "PLAIN");   
    props.put(SaslConfigs.SASL_JAAS_CONFIG, 
      "org.apache.kafka.common.security.plain.PlainLoginModule required username=\"875775227f1ef2eb128a2b5dbb474c8e\" password=\"e87aff2c17454d91deff41d9a1d264f1\";");
    // The Kafka cluster may have encryption enabled. Contact the API owner for the appropriate TrustStore configuration.
    props.put(SslConfigs.SSL_TRUSTSTORE_LOCATION_CONFIG, "C:/@ZZZ/@Workspaces/SpringToolSuite/demo/egw-cert.p12");
    props.put(SslConfigs.SSL_TRUSTSTORE_PASSWORD_CONFIG, "passw0rd");
    props.put(SslConfigs.SSL_TRUSTSTORE_TYPE_CONFIG, "PKCS12");

    KafkaConsumer consumer = new KafkaConsumer<String, byte[]>(props);
    consumer.subscribe(Collections.singletonList("STUDENTZZ.FLIGHT.LANDINGS"));
    try {
      while(true) {
        ConsumerRecords<String, byte[]> records = consumer.poll(Duration.ofSeconds(1));
        Integer qtKafka = new Integer(0);
        for (ConsumerRecord<String, byte[]> record : records) {
        	qtKafka ++;
            byte[] value = record.value();
        	String ZZZString = new String(value);
//          ================================================================
            String key = record.key();
           	System.out.println("Registro: " + ZZZString);
//          ================================================================
//            ByteArrayInputStream bais = new ByteArrayInputStream(value);
//            Decoder decoder = DecoderFactory.get().binaryDecoder(bais, null);
//            GenericRecord genericRecord;
//            genericRecord = reader.read(null, decoder);
//            // Do something with your record
//            Object somefield = genericRecord.get("field-from-your-schema");
//            System.out.println("Qt Total de Registros: " + qtKafka);
          }
        }
    } catch (Exception e) {
      e.printStackTrace();
      consumer.close();
      System.exit(1);
    }   
  }
}